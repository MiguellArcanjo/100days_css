// const senha1 = document.querySelector('.senha');
// const senhaTexto = senha1.value;




// if (senhaTexto === "password") {
//     senha1.style.backgroundColor = "#64C760";
// }